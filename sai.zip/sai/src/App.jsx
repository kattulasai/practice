
import React from 'react'
import LandingPage from './stores/pages/LandingPage'
import './App.css'


const App = () => {
  return (
    <div>
        <LandingPage/>
    </div>
  )
}

export default App